import React from 'react'

const TopicsPage = () => {
  return (
    <div className="container mx-auto px-4 py-16 min-h-screen">
      <h1 className="text-4xl font-bold mb-4">Topics</h1>
      <p>This is the topics page. Content will be added here soon.</p>
    </div>
  )
}

export default TopicsPage